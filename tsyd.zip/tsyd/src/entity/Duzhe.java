package entity;

public class Duzhe implements java.io.Serializable {


	private Integer id;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	private String xingming;
	public String getXingming() {
		return this.xingming;
	}
	public void setXingming(String xingming) {
		this.xingming = xingming;
	}
	private String nianling;
	public String getNianling() {
		return this.nianling;
	}
	public void setNianling(String nianling) {
		this.nianling = nianling;
	}
	private String xingbie;
	public String getXingbie() {
		return this.xingbie;
	}
	public void setXingbie(String xingbie) {
		this.xingbie = xingbie;
	}
	private String lianxidianhua;
	public String getLianxidianhua() {
		return this.lianxidianhua;
	}
	public void setLianxidianhua(String lianxidianhua) {
		this.lianxidianhua = lianxidianhua;
	}
	
}
