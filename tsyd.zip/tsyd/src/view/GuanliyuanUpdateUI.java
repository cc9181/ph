package view;


import dao.*;
import entity.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javafx.stage.FileChooser;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import java.util.List;
import java.util.TreeMap;
import java.util.Map;
import java.util.ArrayList;
import javafx.util.Callback;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.TableColumn.SortType;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Alert.AlertType;
import java.util.UUID;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.event.EventHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.shape.Line;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;

public class GuanliyuanUpdateUI extends AnchorPane {

	private String mainid;
	public String getMainid() {
		return mainid;
	}
	public void setMainid(String mainid) {
		this.mainid = mainid;
	}
	Dao<Guanliyuan> table_199564dao = new Dao(new Guanliyuan());
	ObservableList<Guanliyuan> table_199564data = FXCollections.observableArrayList();
	public GuanliyuanUpdateUI(String param) {
		this.mainid=param;
		Label label_158072=new Label("用户名");
		label_158072.setFont(new Font("宋体", 14));
		label_158072.setPrefWidth(Double.valueOf(100));
		label_158072.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(label_158072, Double.valueOf(150));
		this.setTopAnchor(label_158072, Double.valueOf(60));
		this.getChildren().add(label_158072);
		TextField textField_1919274 = new TextField();
		textField_1919274.setFont(new Font("宋体", 14));
		textField_1919274.setPrefWidth(Double.valueOf(93));
		textField_1919274.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(textField_1919274, Double.valueOf(220));
		this.setTopAnchor(textField_1919274, Double.valueOf(60));
		this.getChildren().add(textField_1919274);
		Label label_1819879=new Label("密码");
		label_1819879.setFont(new Font("宋体", 14));
		label_1819879.setPrefWidth(Double.valueOf(100));
		label_1819879.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(label_1819879, Double.valueOf(370));
		this.setTopAnchor(label_1819879, Double.valueOf(60));
		this.getChildren().add(label_1819879);
		TextField textField_1631440 = new TextField();
		textField_1631440.setFont(new Font("宋体", 14));
		textField_1631440.setPrefWidth(Double.valueOf(93));
		textField_1631440.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(textField_1631440, Double.valueOf(440));
		this.setTopAnchor(textField_1631440, Double.valueOf(60));
		this.getChildren().add(textField_1631440);
		 TableView table_199564=new TableView();
		table_199564.setPrefWidth(Double.valueOf(0));
		table_199564.setPrefHeight(Double.valueOf(0));
		table_199564.setMaxWidth(Double.valueOf(0));
		table_199564.setMaxHeight(Double.valueOf(0));
		table_199564.setMinWidth(Double.valueOf(0));
		table_199564.setMinHeight(Double.valueOf(0));
		this.setLeftAnchor(table_199564, Double.valueOf(0));
		this.setTopAnchor(table_199564, Double.valueOf(0));
		 TableColumn table_199564id=new TableColumn("编号");
		 table_199564id.setCellValueFactory(new PropertyValueFactory<>("id"));
		 table_199564.getColumns().add(table_199564id);
		 TableColumn table_1995640=new TableColumn("用户名");
		 table_1995640.setCellValueFactory(new PropertyValueFactory<>("yonghuming"));
		 table_199564.getColumns().add(table_1995640);
		 TableColumn table_1995641=new TableColumn("密码");
		 table_1995641.setCellValueFactory(new PropertyValueFactory<>("mima"));
		 table_199564.getColumns().add(table_1995641);
		table_199564.setItems(table_199564data);
		this.getChildren().add(table_199564);
		table_199564refresh();
		Button btn_1601016=new Button("保存");
		btn_1601016.setFont(new Font("宋体", 14));
		btn_1601016.setPrefWidth(Double.valueOf(93));
		btn_1601016.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(btn_1601016, Double.valueOf(200));
		this.setTopAnchor(btn_1601016, Double.valueOf(350));
		/**
			修改按钮触发事件
		*/
		btn_1601016.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
		 			Guanliyuan bean = table_199564data.get(Integer.valueOf(param));
				bean.setYonghuming(textField_1919274.getText());
				bean.setMima(textField_1631440.getText());
				table_199564dao.update(bean);
				showMsg("修改成功");
			}
		});
		this.getChildren().add(btn_1601016);
		Button btn_1303215=new Button("关闭");
		btn_1303215.setFont(new Font("宋体", 14));
		btn_1303215.setPrefWidth(Double.valueOf(93));
		btn_1303215.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(btn_1303215, Double.valueOf(300));
		this.setTopAnchor(btn_1303215, Double.valueOf(350));
		btn_1303215.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
			    ((Stage) ((Button)e.getSource()).getScene().getWindow()).close();
			}
		});
		this.getChildren().add(btn_1303215);
		table_199564.setOnMouseClicked(new EventHandler<Event>() {
			public void handle(Event event) {
				int row = table_199564.getSelectionModel().getSelectedIndex();
				if (row == -1) {
					return;
				}
		 			Guanliyuan bean = (Guanliyuan)table_199564.getSelectionModel().getSelectedItems().get(0);
				textField_1919274.setText(bean.getYonghuming());
				textField_1631440.setText(bean.getMima());
				
			};
		});
		table_199564refresh();
		 			Guanliyuan bean = table_199564data.get(Integer.valueOf(param));
				textField_1919274.setText(bean.getYonghuming());
				textField_1631440.setText(bean.getMima());
		
	}
	public void table_199564refresh(){
		table_199564data.clear();
    	table_199564data.addAll(table_199564dao.getAll());
	}
 	public void showMsg(String msg){
   	 Alert alert = new Alert(AlertType.INFORMATION);
        alert.titleProperty().set("提示");
        alert.headerTextProperty().set(msg);
        alert.showAndWait();
   }
}
