package view;


import dao.*;
import entity.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javafx.stage.FileChooser;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import java.util.List;
import java.util.TreeMap;
import java.util.Map;
import java.util.ArrayList;
import javafx.util.Callback;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.TableColumn.SortType;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Alert.AlertType;
import java.util.UUID;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.event.EventHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.shape.Line;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;

public class YuelanshiManageUI extends AnchorPane {

	private String mainid;
	public String getMainid() {
		return mainid;
	}
	public void setMainid(String mainid) {
		this.mainid = mainid;
	}
	Dao<Yuelanshi> table_1409865dao = new Dao(new Yuelanshi());
	ObservableList<Yuelanshi> table_1409865data = FXCollections.observableArrayList();
	public YuelanshiManageUI(String param) {
		this.mainid=param;
		Label label_1393365=new Label("名称");
		label_1393365.setFont(new Font("宋体", 14));
		label_1393365.setPrefWidth(Double.valueOf(100));
		label_1393365.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(label_1393365, Double.valueOf(150));
		this.setTopAnchor(label_1393365, Double.valueOf(30));
		this.getChildren().add(label_1393365);
		TextField textField_114480 = new TextField();
		textField_114480.setFont(new Font("宋体", 14));
		textField_114480.setPrefWidth(Double.valueOf(93));
		textField_114480.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(textField_114480, Double.valueOf(220));
		this.setTopAnchor(textField_114480, Double.valueOf(30));
		this.getChildren().add(textField_114480);
		 TableView table_1409865=new TableView();
		table_1409865.setPrefWidth(Double.valueOf(800));
		table_1409865.setPrefHeight(Double.valueOf(400));
		table_1409865.setMaxWidth(Double.valueOf(800));
		table_1409865.setMaxHeight(Double.valueOf(400));
		table_1409865.setMinWidth(Double.valueOf(800));
		table_1409865.setMinHeight(Double.valueOf(400));
		this.setLeftAnchor(table_1409865, Double.valueOf(190));
		this.setTopAnchor(table_1409865, Double.valueOf(145));
		 TableColumn table_1409865id=new TableColumn("编号");
		 table_1409865id.setCellValueFactory(new PropertyValueFactory<>("id"));
		 table_1409865.getColumns().add(table_1409865id);
		 TableColumn table_14098650=new TableColumn("名称");
		 table_14098650.setCellValueFactory(new PropertyValueFactory<>("mingcheng"));
		 table_1409865.getColumns().add(table_14098650);
		table_1409865.setItems(table_1409865data);
		this.getChildren().add(table_1409865);
		table_1409865refresh();
		Button btn_1625399=new Button("新增");
		btn_1625399.setFont(new Font("宋体", 14));
		btn_1625399.setPrefWidth(Double.valueOf(93));
		btn_1625399.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(btn_1625399, Double.valueOf(200));
		this.setTopAnchor(btn_1625399, Double.valueOf(100));
		btn_1625399.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
			    Stage stage=new Stage();
			    stage.setTitle("新增");
			    stage.setScene(new Scene(new YuelanshiAddUI(""),600,600));
			    stage.show();
			}
		});
		this.getChildren().add(btn_1625399);
		Button btn_1206470=new Button("修改");
		btn_1206470.setFont(new Font("宋体", 14));
		btn_1206470.setPrefWidth(Double.valueOf(93));
		btn_1206470.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(btn_1206470, Double.valueOf(300));
		this.setTopAnchor(btn_1206470, Double.valueOf(100));
		/**
			修改按钮触发事件
		*/
		btn_1206470.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				int row = table_1409865.getSelectionModel().getSelectedIndex();
				if (row == -1) {
					showMsg("请选择一行");
					return;
				}
			    Stage stage=new Stage();
			    stage.setTitle("修改");
			    stage.setScene(new Scene(new YuelanshiUpdateUI(String.valueOf(row)),600,600));
			    stage.show();
			}
		});
		this.getChildren().add(btn_1206470);
		Button btn_1465124=new Button("删除");
		btn_1465124.setFont(new Font("宋体", 14));
		btn_1465124.setPrefWidth(Double.valueOf(93));
		btn_1465124.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(btn_1465124, Double.valueOf(400));
		this.setTopAnchor(btn_1465124, Double.valueOf(100));
		btn_1465124.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				int row = table_1409865.getSelectionModel().getSelectedIndex();
				if (row == -1) {
					showMsg("请选择一行");
					return;
				}
				Yuelanshi bean = (Yuelanshi)table_1409865.getSelectionModel().getSelectedItems().get(0);
				table_1409865dao.delBykey("id", bean.getId().toString());
				showMsg("删除成功");
				table_1409865refresh();
				
			}
		});
		this.getChildren().add(btn_1465124);
		Button btn_1188989=new Button("查询");
		btn_1188989.setFont(new Font("宋体", 14));
		btn_1188989.setPrefWidth(Double.valueOf(93));
		btn_1188989.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(btn_1188989, Double.valueOf(500));
		this.setTopAnchor(btn_1188989, Double.valueOf(100));
		btn_1188989.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				Yuelanshi bean=new Yuelanshi();
				bean.setMingcheng(textField_114480.getText());
				table_1409865data.clear();
				table_1409865data.addAll(table_1409865dao.query(bean));
				
			}
		});
		this.getChildren().add(btn_1188989);
		Button btn_180243=new Button("重置");
		btn_180243.setFont(new Font("宋体", 14));
		btn_180243.setPrefWidth(Double.valueOf(93));
		btn_180243.setPrefHeight(Double.valueOf(23));
		this.setLeftAnchor(btn_180243, Double.valueOf(600));
		this.setTopAnchor(btn_180243, Double.valueOf(100));
		btn_180243.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				textField_114480.setText("");
			}
		});
		this.getChildren().add(btn_180243);
		table_1409865.setOnMouseClicked(new EventHandler<Event>() {
			public void handle(Event event) {
				int row = table_1409865.getSelectionModel().getSelectedIndex();
				if (row == -1) {
					return;
				}
		 			Yuelanshi bean = (Yuelanshi)table_1409865.getSelectionModel().getSelectedItems().get(0);
				textField_114480.setText(bean.getMingcheng());
				
			};
		});
		table_1409865refresh();
		
	}
	public void table_1409865refresh(){
		table_1409865data.clear();
    	table_1409865data.addAll(table_1409865dao.getAll());
	}
 	public void showMsg(String msg){
   	 Alert alert = new Alert(AlertType.INFORMATION);
        alert.titleProperty().set("提示");
        alert.headerTextProperty().set(msg);
        alert.showAndWait();
   }
}
