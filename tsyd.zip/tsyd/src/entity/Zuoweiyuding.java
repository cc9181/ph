package entity;

public class Zuoweiyuding implements java.io.Serializable {


	private Integer id;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	private String duzhe;
	public String getDuzhe() {
		return this.duzhe;
	}
	public void setDuzhe(String duzhe) {
		this.duzhe = duzhe;
	}
	private String zuowei;
	public String getZuowei() {
		return this.zuowei;
	}
	public void setZuowei(String zuowei) {
		this.zuowei = zuowei;
	}
	private String yuelanshi;
	public String getYuelanshi() {
		return this.yuelanshi;
	}
	public void setYuelanshi(String yuelanshi) {
		this.yuelanshi = yuelanshi;
	}
	private String riqi;
	public String getRiqi() {
		return this.riqi;
	}
	public void setRiqi(String riqi) {
		this.riqi = riqi;
	}
	private String shijian;
	public String getShijian() {
		return this.shijian;
	}
	public void setShijian(String shijian) {
		this.shijian = shijian;
	}
	
}
