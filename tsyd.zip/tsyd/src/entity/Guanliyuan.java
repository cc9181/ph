package entity;

public class Guanliyuan implements java.io.Serializable {


	private Integer id;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	private String yonghuming;
	public String getYonghuming() {
		return this.yonghuming;
	}
	public void setYonghuming(String yonghuming) {
		this.yonghuming = yonghuming;
	}
	private String mima;
	public String getMima() {
		return this.mima;
	}
	public void setMima(String mima) {
		this.mima = mima;
	}
	
}
