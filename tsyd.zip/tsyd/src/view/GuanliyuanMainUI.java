package view;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javafx.stage.FileChooser;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;

import java.util.*;

import javafx.util.Callback;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.TableColumn.SortType;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Alert.AlertType;

import java.text.SimpleDateFormat;

import javafx.event.EventHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.shape.Line;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;

public class GuanliyuanMainUI extends AnchorPane {

	private String username;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	private String mainid;
	public String getMainid() {
		return mainid;
	}
	public void setMainid(String mainid) {
		this.mainid = mainid;
	}
	public GuanliyuanMainUI(String param) {
		// 加载 CSS 文件
		this.mainid=param;
		this.getStyleClass().add("background-pane");
		Button btn_1702854=new Button("管理员管理");
		btn_1702854.setFont(new Font("楷体", 20));
		btn_1702854.setPrefWidth(Double.valueOf(180));
		btn_1702854.setPrefHeight(Double.valueOf(40));
		this.setLeftAnchor(btn_1702854, Double.valueOf(200));
		this.setTopAnchor(btn_1702854, Double.valueOf(10));
		btn_1702854.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
			    Stage stage=new Stage();
			    stage.setTitle("管理员管理");
			    stage.setScene(new Scene(new GuanliyuanManageUI(""),1200,730));
			    stage.show();
			}
		});
		this.getChildren().add(btn_1702854);
		Button btn_17660=new Button("读者管理");
		btn_17660.setFont(new Font("楷体", 20));
		btn_17660.setPrefWidth(Double.valueOf(180));
		btn_17660.setPrefHeight(Double.valueOf(40));
		this.setLeftAnchor(btn_17660, Double.valueOf(200));
		this.setTopAnchor(btn_17660, Double.valueOf(60));
		btn_17660.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
			    Stage stage=new Stage();
			    stage.setTitle("读者管理");
			    stage.setScene(new Scene(new DuzheManageUI(""),1200,730));
			    stage.show();
			}
		});
		this.getChildren().add(btn_17660);
		Button btn_1580924=new Button("阅览室管理");
		btn_1580924.setFont(new Font("楷体", 20));
		btn_1580924.setPrefWidth(Double.valueOf(180));
		btn_1580924.setPrefHeight(Double.valueOf(40));
		this.setLeftAnchor(btn_1580924, Double.valueOf(200));
		this.setTopAnchor(btn_1580924, Double.valueOf(110));
		btn_1580924.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
			    Stage stage=new Stage();
			    stage.setTitle("阅览室管理");
			    stage.setScene(new Scene(new YuelanshiManageUI(""),1200,730));
			    stage.show();
			}
		});
		this.getChildren().add(btn_1580924);
		Button btn_1277399=new Button("座位预定管理");
		btn_1277399.setFont(new Font("楷体", 20));
		btn_1277399.setPrefWidth(Double.valueOf(180));
		btn_1277399.setPrefHeight(Double.valueOf(40));
		this.setLeftAnchor(btn_1277399, Double.valueOf(200));
		this.setTopAnchor(btn_1277399, Double.valueOf(160));
		btn_1277399.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
			    Stage stage=new Stage();
			    stage.setTitle("座位预定管理");
			    stage.setScene(new Scene(new ZuoweiyudingManageUI(""),1200,730));
			    stage.show();
			}
		});
		this.getChildren().add(btn_1277399);
		Button btn_1631070=new Button("退出");
		btn_1631070.setFont(new Font("楷体", 20));
		btn_1631070.setPrefWidth(Double.valueOf(180));
		btn_1631070.setPrefHeight(Double.valueOf(40));
		this.setLeftAnchor(btn_1631070, Double.valueOf(200));
		this.setTopAnchor(btn_1631070, Double.valueOf(210));
		btn_1631070.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				System.exit(0);
			}
		});
		this.getChildren().add(btn_1631070);
		
	}
 	public void showMsg(String msg){
   	 Alert alert = new Alert(AlertType.INFORMATION);
        alert.titleProperty().set("提示");
        alert.headerTextProperty().set(msg);
        alert.showAndWait();
   }
}
